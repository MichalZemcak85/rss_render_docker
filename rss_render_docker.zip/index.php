<?php
echo "Stránka běží. Zkuste /rss.php";
?>