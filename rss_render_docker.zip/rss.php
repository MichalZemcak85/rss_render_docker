<?php
header('Content-Type: application/rss+xml; charset=utf-8');

echo '<?xml version="1.0" encoding="UTF-8" ?>';
?>
<rss version="2.0">
  <channel>
    <title>Ukázkový RSS feed</title>
    <link>https://example.com</link>
    <description>Testovací RSS feed pro Render.com</description>
    <item>
      <title>Položka 1</title>
      <link>https://example.com/post1</link>
      <description>První ukázková položka</description>
    </item>
  </channel>
</rss>